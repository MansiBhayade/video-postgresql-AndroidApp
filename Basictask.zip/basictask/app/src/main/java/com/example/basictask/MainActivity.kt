package com.example.basictask

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.lifecycleScope
import com.example.basictask.ui.theme.BasictaskTheme
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        getData()
        setContent {
            BasictaskTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Greeting("Android")
                }
            }



        }
    }

    private fun getData(){
     lifecycleScope.launch {
         val client = getClient()
         val superbaseResponse = client.postgrest["Vediolist"].select()
         val data = superbaseResponse.decodeList<Vediolist>()
         Log.e("superbase", data.toString())
     }
    }

    private fun getClient(){
        val client = createSupabaseClient(
            supabaseUrl = "https://swrzxmhocwsaaovbhcoh.supabase.co",
            supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN3cnp4bWhvY3dzYWFvdmJoY29oIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTQ5ODYyODksImV4cCI6MjAzMDU2MjI4OX0.giHJU4tK3fqrqMBr0mLHlx68LT6N4iGxXutZieg5pgY",

        ){
           install(Postgrest)
        }

    }
}

@Serializable
data class Vediolist(
    val id: Int =0,
    val Channel_name: String=" ",
    val Title: String = " ",
    val description: String = " ",
    val likes: Int =0,
    val dislikes: Int =0
)

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    BasictaskTheme {
        Greeting("Android")
    }
}